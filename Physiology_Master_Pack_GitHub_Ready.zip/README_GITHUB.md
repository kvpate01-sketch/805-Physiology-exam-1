# Physiology Master Pack — GitHub Pages setup

## Files to upload
Keep these files together in the **same repository folder**:

- `index.html`
- `01_muscle_physiology.html`
- `muscle_mastery_quiz_135q.html`
- `02_circulatory_physiology.html`
- `03_respiratory_physiology.html`

The relative links between them will work automatically as long as the filenames stay the same.

## Easiest method: GitHub website

1. Sign in to GitHub.
2. Click **New repository**.
3. Name it something like `physiology-study-guide`.
4. Choose **Public** if you want normal free GitHub Pages access.
5. Create the repository.
6. Click **Add file → Upload files**.
7. Drag all five files above into the upload area.
8. Click **Commit changes**.
9. Open **Settings → Pages**.
10. Under **Build and deployment**, choose **Deploy from a branch**.
11. Select branch **main** and folder **/(root)**.
12. Click **Save**.
13. GitHub will give you a Pages address similar to:
   `https://YOUR-USERNAME.github.io/physiology-study-guide/`
14. Opening that address loads `index.html`, which launches all three chapters.

## Updating later

If ChatGPT gives you a newer version of one chapter:
1. Download the replacement HTML.
2. In the GitHub repository, open the old file.
3. Delete/replace it or use **Add file → Upload files** and overwrite using the same filename.
4. Commit changes.
5. GitHub Pages updates automatically after deployment finishes.

## Optional: Git command-line method

```bash
git clone https://github.com/YOUR-USERNAME/physiology-study-guide.git
cd physiology-study-guide
# copy the HTML files here
git add .
git commit -m "Add physiology study guides"
git push
```

Then enable GitHub Pages in **Settings → Pages → Deploy from a branch → main → /(root)**.

## Important
Do not rename `muscle_mastery_quiz_135q.html` unless you also change the iframe link inside `01_muscle_physiology.html`.
